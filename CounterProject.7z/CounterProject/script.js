let counter=0;

document.querySelector('#increment').addEventListener('click', function(){
    counter++;
    document.querySelector('.display').textContent=counter;
})

document.querySelector('#decrement').addEventListener('click', function(){
    counter--;
    document.querySelector('.display').textContent=counter;
    if(counter<0){
        alert('Cant go below this')
        document.querySelector('.display').textContent=0;
    }
})